package com.example.pembiayaanqu.view.activity;


import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toolbar;

import com.example.pembiayaanqu.MainActivity;
import com.example.pembiayaanqu.R;
import com.example.pembiayaanqu.view.fragment.account;
import com.example.pembiayaanqu.view.fragment.information;
import com.example.pembiayaanqu.view.fragment.main;
import com.facebook.login.LoginManager;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserInfo;

public class home extends AppCompatActivity {

    private FirebaseAuth mAuth;
    private Button logout;
    private BottomNavigationView bottomNavigationView;
    private Toolbar toolbar;
    private ImageView logo;
    private ImageView hamburger;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home);

        mAuth = FirebaseAuth.getInstance();
        bottomNavigationView = findViewById(R.id.bottomNavigationView);
        logo = findViewById(R.id.logo);
        hamburger= findViewById(R.id.hamburger);
        toolbar = findViewById(R.id.toolbar);

        updateBottomNavigation();


        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(MenuItem menuItem) {
                switch (menuItem.getItemId()) {
                    case R.id.home:
                        changeFragment(new main());
                        menuItem.setChecked(true);
                        toolbar.setVisibility(View.VISIBLE);
                        logo.setVisibility(View.VISIBLE);
                        hamburger.setVisibility(View.VISIBLE);
                        break;
                    case R.id.account:
                        changeFragment(new account());
                        menuItem.setChecked(true);
                        toolbar.setVisibility(View.GONE);
                        logo.setVisibility(View.GONE);
                        hamburger.setVisibility(View.GONE);
                        break;
                    case R.id.information:
                        changeFragment(new information());
                        menuItem.setChecked(true);
                        toolbar.setVisibility(View.GONE);
                        logo.setVisibility(View.GONE);
                        hamburger.setVisibility(View.GONE);
                        break;
                    case R.id.login:
                        Intent login = new Intent(home.this, MainActivity.class);
                        startActivity(login);
                        finish();
                        break;
                    case R.id.logout:
                        logout();
                        break;
                }
                return false;
            }
        });



        FirebaseUser user = mAuth.getCurrentUser();
        if (user != null) {
            for (UserInfo profile : user.getProviderData()) {
                // Id of the provider (ex: google.com)
                String providerId = profile.getProviderId();

                // UID specific to the provider
                String uid = profile.getUid();

                // Name, email address, and profile photo Url
                String name = profile.getDisplayName();
                String email = profile.getEmail();
//                String photoUrl = profile.getPhotoUrl().toString();
//                ImageView photoview = (ImageView)findViewById(R.id.photo);
//                Glide.with(this).load(photoUrl).into(photoview);
            }
        }


    }

    @Override
    public void onStart() {
        super.onStart();
    }


    private void logout(){
        mAuth.signOut();
        LoginManager.getInstance().logOut();
        updateUI();
    }

    private void updateUI() {
        Intent home = new Intent(home.this, home.class);
        startActivity(home);
        finish();
    }


    private void updateBottomNavigation(){
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser == null){
            bottomNavigationView.getMenu().clear();
            bottomNavigationView.inflateMenu(R.menu.nav_item_login);
        }else{
            bottomNavigationView.getMenu().clear();
            bottomNavigationView.inflateMenu(R.menu.nav_item_logout);
        }
    }

    private void changeFragment(Fragment fragment){
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        ft.replace(R.id.frameLayout, fragment);
        ft.commit();
    }
}
